<?php

require_once "core/database/Model.php";
class CoinHistory extends Model
{
   // Attributes
   protected $id;

   protected $date;

   protected $coin_side;

    protected $user_id;

    public function create()
    {
        $dbh = App::get('dbh');
        $req = "INSERT INTO coin_history (coin_side, user_id) VALUES (?, ?)";
        $statement = $dbh->prepare($req);
        $statement->bindParam(1, $this->coin_side, PDO::PARAM_STR);
        $statement->bindParam(2, $this->user_id, PDO::PARAM_INT);
        $statement->execute();
    }

    public static function allByUser($user_id)
    {
        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM coin_history WHERE user_id=:user_id ORDER BY id DESC LIMIT 20");
        $statement->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'CoinHistory');
        $statement->execute();
        return $statement->fetchAll();
    }

}
