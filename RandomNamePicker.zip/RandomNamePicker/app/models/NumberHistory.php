<?php

require_once "core/database/Model.php";
class NumberHistory extends Model
{
   // Attributes
   protected $id;

   protected $date;

   protected $random_number;

   protected $min;

   protected $max;


    protected $user_id;

    public function create()
    {
        $dbh = App::get('dbh');
        $req = "INSERT INTO number_history (random_number, user_id , min , max) VALUES (?, ? , ? , ?)";
        $statement = $dbh->prepare($req);
        $statement->bindParam(1, $this->random_number, PDO::PARAM_INT);
        $statement->bindParam(2, $this->user_id, PDO::PARAM_INT);
        $statement->bindParam(3, $this->min, PDO::PARAM_INT);
        $statement->bindParam(4, $this->max, PDO::PARAM_INT);
        $statement->execute();
    }

    public static function allByUser($user_id)
    {
        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM number_history WHERE user_id=:user_id ORDER BY id DESC LIMIT 20");
        $statement->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'NumberHistory');
        $statement->execute();
        return $statement->fetchAll();
    }

    public static function find($id)
    {
        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM number_history WHERE id=:id");
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'NumberHistory');
        $statement->execute();
        return $statement->fetch();
    }

}
