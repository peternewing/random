<?php

require_once "core/database/Model.php";
class NameHistory extends Model
{
   // Attributes
   protected $id;

   protected $date;

   protected $generated_name;

   protected $gender;

   protected $num_last_names;


    protected $user_id;

    public function create()
    {
        $dbh = App::get('dbh');
        $req = "INSERT INTO name_history (generated_name, user_id , gender , num_last_names) VALUES (?, ? , ? , ?)";
        $statement = $dbh->prepare($req);
        $statement->bindParam(1, $this->generated_name, PDO::PARAM_STR);
        $statement->bindParam(2, $this->user_id, PDO::PARAM_INT);
        $statement->bindParam(3, $this->gender, PDO::PARAM_STR);
        $statement->bindParam(4, $this->num_last_names, PDO::PARAM_STR);
        $statement->execute();
    }

    public static function allByUser($user_id)
    {
        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM name_history WHERE user_id=:user_id ORDER BY id DESC LIMIT 20");
        $statement->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'NameHistory');
        $statement->execute();
        return $statement->fetchAll();
    }

    public static function find($id)
    {
        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM name_history WHERE id=:id");
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'NameHistory');
        $statement->execute();
        return $statement->fetch();
    }

}
