<?php

require_once "core/database/Model.php";
class PasswordHistory extends Model
{
   // Attributes
   protected $id;

   protected $date;

   protected $password;

    protected $user_id;

    protected $length;

    protected $special_chars;

    protected $numbers;

    protected $uppercase;

    public function create()
    {
        $dbh = App::get('dbh');
        $req = "INSERT INTO password_history (password, user_id , length , special_chars , numbers , uppercase) VALUES (?, ? , ?, ?, ?, ?)";
        $statement = $dbh->prepare($req);
        $statement->bindParam(1, $this->password, PDO::PARAM_STR);
        $statement->bindParam(2, $this->user_id, PDO::PARAM_INT);
        $statement->bindParam(3, $this->length, PDO::PARAM_INT);
        $statement->bindParam(4, $this->special_chars, PDO::PARAM_BOOL);
        $statement->bindParam(5, $this->numbers, PDO::PARAM_BOOL);
        $statement->bindParam(6, $this->uppercase, PDO::PARAM_BOOL);
        $statement->execute();
    }

    public static function allByUser($user_id)
    {
        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM password_history WHERE user_id=:user_id ORDER BY id DESC LIMIT 20");
        $statement->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'PasswordHistory');
        $statement->execute();
        return $statement->fetchAll();
    }


    public static function find($id)
    {
     

        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM password_history WHERE id=:id");
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'PasswordHistory');
        $statement->execute();
        return $statement->fetch();
    }



}
