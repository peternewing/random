<?php

require_once "core/database/Model.php";
class DiceHistory extends Model
{
   // Attributes
   protected $id;

   protected $date;

   protected $dice_rolls;

   protected $total;

   protected $number_of_rolls;

    protected $user_id;

    public function create()
    {
        $dbh = App::get('dbh');
        $req = "INSERT INTO dice_history (dice_rolls , total , number_of_rolls , user_id) VALUES (?, ?,?, ?)";
        $statement = $dbh->prepare($req);
        $statement->bindParam(1, $this->dice_rolls, PDO::PARAM_STR);
        $statement->bindParam(2, $this->total, PDO::PARAM_INT);
        $statement->bindParam(3, $this->number_of_rolls, PDO::PARAM_INT);
        $statement->bindParam(4, $this->user_id, PDO::PARAM_INT);
        $statement->execute();
    }

    public static function allByUser($user_id)
    {
        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM dice_history WHERE user_id=:user_id ORDER BY id DESC LIMIT 20");
        $statement->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'DiceHistory');
        $statement->execute();
        return $statement->fetchAll();
    }

}
