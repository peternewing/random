<?php

require_once "core/database/Model.php";
class RandomTeam extends Model
{
   // Attributes
   protected $id;

   protected $date;

   protected $team_name;

   protected $num_teams;

   protected $participants;

    protected $user_id;

    public function create()
    {
        $dbh = App::get('dbh');
        $req = "INSERT INTO random_team (team_name, user_id , num_teams , participants) VALUES (?, ? , ? , ?)";
        $statement = $dbh->prepare($req);
        $statement->bindParam(1, $this->team_name, PDO::PARAM_STR);
        $statement->bindParam(2, $this->user_id, PDO::PARAM_INT);
        $statement->bindParam(3, $this->num_teams, PDO::PARAM_INT);
        $statement->bindParam(4, $this->participants, PDO::PARAM_STR);
        $statement->execute();
    }

    public static function allByUser($user_id)
    {
        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM random_team WHERE user_id=:user_id ORDER BY id DESC");
        $statement->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'RandomTeam');
        $statement->execute();
        return $statement->fetchAll();
    }

    public static function find($id)
    {
        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM random_team WHERE id=:id");
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'RandomTeam');
        $statement->execute();
        return $statement->fetch();
    }


}
