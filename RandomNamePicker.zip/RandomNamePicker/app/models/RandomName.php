<?php

require_once "core/database/Model.php";
class RandomName extends Model
{
   // Attributes
   protected $id;

   protected $date;

   protected $list_name;

   protected $names;

    protected $user_id;

    public function create()
    {
        $dbh = App::get('dbh');
        $req = "INSERT INTO random_name (list_name, user_id ,  names) VALUES (?, ?  , ?)";
        $statement = $dbh->prepare($req);
        $statement->bindParam(1, $this->list_name, PDO::PARAM_STR);
        $statement->bindParam(2, $this->user_id, PDO::PARAM_INT);
        $statement->bindParam(3, $this->names, PDO::PARAM_STR);
        $statement->execute();
    }

    public static function allByUser($user_id)
    {
        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM random_name WHERE user_id=:user_id ORDER BY id DESC");
        $statement->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'RandomName');
        $statement->execute();
        return $statement->fetchAll();
    }

    public static function find($id)
    {
        $dbh = App::get('dbh');
        $statement = $dbh->prepare("SELECT * FROM random_name WHERE id=:id");
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        $statement->setFetchMode(PDO::FETCH_CLASS, 'RandomName');
        $statement->execute();
        return $statement->fetch();
    }


}
