<?php
  $title =  "Flip a Coin";
    require('partials/header.php')
?>


<main class="container">

  <h1 class="text-center m-5"><?=  $title ?></h1>

  <div class="row">
    <div class="col-md-6 p-2">
        <h2 class="my-4 text-center"></h2>
      
        <form action="flip_a_coin_post" method="post">
    <input type="submit" class="btn btn-primary" value="Flip the Coin">
    </form>
    </div>
    <div class="col-md-6 p-2">

        <h2 class="my-4 text-center">Result</h2>

        <?php if (isset($coin_flip)) : ?>
            <div class='alert alert-success'>The coin flip result is: <strong><?=  htmlspecialchars($coin_flip) ?></strong></div>
        <?php endif; ?>
    </div>
</div>

          <div class="row">
            <div class="col-md-6 p-2">
                <h2 class="my-4 text-center">Coin Flip History</h2>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Coin Side</th>
                            <th scope="col">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($coin_history as $coin) : ?>
                            <tr>
                                <td><?=  htmlspecialchars($coin->coin_side) ?></td>
                                <td><?=  htmlspecialchars($coin->date) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        


</main>


<?php require('partials/footer.php') ?>