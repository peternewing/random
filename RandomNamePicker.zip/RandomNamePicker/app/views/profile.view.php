<?php
    $title = "Your Profile Page";
    require('partials/header.php')
?>



<main class="container">

        <div class="wrapper fadeInDown">
            <div id="formContent">
                <!-- Tabs Titles -->

                <!-- Icon -->
                <div class="fadeIn first">
                    <img src="./assets/logo.png" id="icon" alt="User Icon" class="mt-3"/>
                    <h1><?= $title ?></h1>
                </div>

                <!-- Register Form -->
                <form class="mt-5" action="edit_profile" method="POST">
                 <input type="text" class="form-control" id="firstName" name="firstName" required placeholder="First Name" value="<?= $user->first_name ?>">
                 <input type="text" class="form-control" id="lastName" name="lastName" required placeholder="Last Name" value="<?= $user->last_name ?>">
                 <input type="text" class="form-control" id="email" name="email" required placeholder="UserName" value="<?= $user->email ?>">
                 <input type="password" class="form-control" id="password" name="password" required placeholder="Password">
                 <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Confirm Password" required>
                <input type="submit" class="fadeIn fourth" value="Update Profile">
                </form>

            </div>
        </div>
</main>


<?php require('partials/footer.php') ?>
