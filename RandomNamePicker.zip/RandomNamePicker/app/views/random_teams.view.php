<?php
    $title = "Random Team Generator";
    require('partials/header.php')
?>

<main class="container">

  <h1 class="text-center m-5"><?=  $title ?></h1>

<div class="row">
    <div class="col-md-6 p-2">
        <h2 class="my-4 text-center">Generate Teams</h2>
        <form id="generateFormTeam" action="generate_teams_post" method="post">
            <div id="participants">
            <?php if (isset($participants)) : ?>
                <?php foreach ($participants as $participant) : ?>
                <div class="mb-3 input-group">
                    <input type="text" name="participants[]" class="form-control" value="<?= $participant ?>" placeholder="Enter Participant Name">
                    <button type="button" class="btn btn-danger" onclick="this.parentElement.remove()">Remove</button>
                </div>
                <?php endforeach; ?>
                <?php else : ?>
                    <div class="mb-3 input-group">
                    <input type="text" name="participants[]" class="form-control" placeholder="Enter Participant Name">
                    <button type="button" class="btn btn-danger" onclick="this.parentElement.remove()">Remove</button>
                </div>
                <?php endif; ?>
            </div>
            <button type="button" class="btn btn-secondary mb-3" onclick="addParticipantField()">Add Participant</button><br>
            <div class="mb-3">
                <label for="numTeams" class="form-label">Enter Number of Teams:</label>
                <input type="number" id="numTeams" name="numTeams" class="form-control" min="1" value="<?= isset($numTeams)?$numTeams:null ?>" required>
            </div>
            <input type="submit" class="btn btn-primary" value="Generate Teams">
        </form>

        <form id="saveFormTeam" action="save_team_post" method="post">
            <div class="mb-3">
                <label for="TeamName" class="form-label">Enter Team Name:</label>
                <input type="hidden" name="teamId" value="<?= isset($teamId)?$teamId:null ?>">
                <input type="text" id="TeamName" name="TeamName" class="form-control" min="1" value="<?= isset($teamName)?$teamName:null ?>" required>
            </div>
            <input type="submit" class="btn btn-primary" value="Save Teams">
        </form>

    </div>
    <div class="col-md-6 p-2">

        <h2 class="my-4 text-center">Generated Teams</h2>

        <?php if (isset($teams)) : ?>
            <?php foreach ($teams as $teamNumber => $team) : ?>
                <div class="card mb-3">
                    <div class="card-body">
                        <h2 class="card-title">Team <?= $teamNumber + 1 ?>:</h2>
                        <p class="card-text"><?= implode(", ", $team) ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
         



</div>
<div class="row">
    <div class="col-md-12 p-2">
        <h2 class="my-4 text-center">Saved Teams</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                <th scope="col">Name Teams</th>
                    <th scope="col">Number Teams</th>
                    <th scope="col">Participant</th>
                    <th scope="col">Date</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($saved_teams as $teams) : ?>
                    <tr>
                    <td><?=  htmlspecialchars($teams->team_name) ?></td>
                        <td><?=  htmlspecialchars($teams->num_teams) ?></td>
                        <td>
                            <?php 
                                $participants = json_decode($teams->participants);
                                foreach ($participants as $participant) : ?>
                                    <span class="badge bg-secondary"><?=  htmlspecialchars($participant) ?></span>
                                <?php endforeach; ?>
                        </td>
                        <td><?=  htmlspecialchars($teams->date) ?></td>
                        <td>
                            <a href="random_team?teams_id=<?=  htmlspecialchars($teams->id) ?>" class="btn btn-primary">Load Teams</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>


</main>


<?php require('partials/footer.php') ?>