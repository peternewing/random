<?php
    $title = "Register Page";
    require('partials/header.php')
?>



<main class="container">

        <div class="wrapper fadeInDown">
            <div id="formContent">
                <!-- Tabs Titles -->

                <!-- Icon -->
                <div class="fadeIn first">
                    <img src="./assets/logo.png" id="icon" alt="User Icon" class="mt-3"/>
                    <h1>Register</h1>
                </div>

                <!-- Register Form -->
                <form class="mt-5" action="register" method="POST">
                 <input type="text" class="form-control" id="firstName" name="firstName" required placeholder="First Name">
                 <input type="text" class="form-control" id="lastName" name="lastName" required placeholder="Last Name">
                 <input type="text" class="form-control" id="email" name="email" required placeholder="UserName">
                 <input type="password" class="form-control" id="password" name="password" required placeholder="Password">
                 <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Confirm Password" required>
                <input type="submit" class="fadeIn fourth" value="Register">
                </form>

                <!-- Remind Passowrd -->
                <div id="formFooter">
                You have an account? <a class="underlineHover" href="./login_form">Login</a>
                </div>

            </div>
        </div>
</main>


<?php require('partials/footer.php') ?>
