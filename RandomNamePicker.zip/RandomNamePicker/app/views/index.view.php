<?php
    $title = "Home Page";
    require('partials/header.php')
?>

<main class="container">

  <h1 class="text-center m-5">Home Page</h1>


  <div class="row">
    <div class="col-12 col-md-6 text-center">
      <h2 class="text-center">Random Name Picker</h2>
      <p class="text-center">This is a simple random name picker. You can add names to the list and pick a random name from the list.</p>
      <a href="./article_random_name_picker" class="btn btn-primary mx-auto">Read more</a>
    </div>
    <div class="col-12 col-md-6 text-center">
      <h2 class="text-center">Random Team Generator</h2>
      <p class="text-center">This is a simple random team generator. You can add names to the list and generate random teams.</p>
      <a href="./article_random_team_generator" class="btn btn-primary mx-auto">Read more</a>
    </div>
  </div>
  
   
  <div class="row mt-5">
    <div class="col-12 col-md-6 text-center">
      <h2 class="text-center">Generate Random Name</h2>
      <p class="text-center">This is a simple random name generator. You can generate random names.</p>
      <a href="./article_generate_random_name" class="btn btn-primary mx-auto">Read more</a>
    </div>


    <div class="col-12 col-md-6 text-center">
      <h2 class="text-center">Online Dice Roller</h2>
      <p class="text-center"> 
         This is a simple online dice roller. You can roll a dice and get a random number between 1 and 6.    
    </p>
      <a href="./article_dice_roller" class="btn btn-primary mx-auto">Read more</a>
    </div>

    
   
  </div>

  <div class="row mt-5">
    <div class="col-12 col-md-6 text-center">
      <h2 class="text-center">Flip a Coin</h2>
      <p class="text-center"> 
         This is a simple coin flipper. You can flip a coin and get a random result: heads or tails.
      </p>
      <a href="./article_flip_a_coin" class="btn btn-primary mx-auto">Read more</a>
    </div>

    <div class="col-12 col-md-6 text-center">
      <h2 class="text-center">Random Number Generator</h2>
      <p class="text-center"> 
         This is a simple random number generator. You can generate random numbers between 1 and 100.
      </p>
      <a href="./article_random_number_generator" class="btn btn-primary mx-auto">Read more</a>

    </div>
  </div>


    <div class="row mt-5">
    <div class="col-12 col-md-6 text-center">
      <h2 class="text-center">Random Password Generator</h2>
      <p class="text-center"> 
         This is a simple random password generator. You can generate random passwords.
      </p>
      <a href="./article_random_password_generator" class="btn btn-primary mx-auto">Read more</a>
    </div>


    <div class="col-12 col-md-6 text-center">
      <h2 class="text-center">Random Color Generator</h2>
      <p class="text-center"> 
         This is a simple random color generator. You can generate random colors.
      </p>
      <a href="./article_random_color_generator" class="btn btn-primary mx-auto">Read more</a>
    </div>

  </div>

  <div class="row mt-5">
    <div class="col-12 col-md-6 text-center">
      <h2 class="text-center">Character Counter</h2>
      <p class="text-center"> 
          This is a simple character counter. You can count the number of characters in a text.
      </p>
      <a href="./article_character_counter" class="btn btn-primary mx-auto">Read more</a>
    </div>


  </div>



   

  

  
</main>


<?php require('partials/footer.php') ?>
