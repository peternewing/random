<?php
    $title = "Login Page";
    require('partials/header.php')
?>


<main class="container">

        <div class="wrapper fadeInDown">
            <div id="formContent">
                <!-- Tabs Titles -->

                <!-- Icon -->
                <div class="fadeIn first">
                <img src="./assets/logo.png" id="icon" alt="User Icon" class="mt-3" />
                <h1>Login</h1>
                </div>

                <!-- Login Form -->
                <form class="mt-5" action="login" method="POST">
                <input type="text" class="form-control fadeIn second" id="username" name="username" placeholder="username" required>
                <input type="password" class="form-control fadeIn third" id="password" name="password" placeholder="Password" required>
                <input type="submit" class="fadeIn fourth" value="Log In">
                </form>

                <!-- Remind Passowrd -->
                <div id="formFooter">
                You don't have an account? <a class="underlineHover" href="./register_form">Register</a>
                </div>

            </div>
        </div>
</main>


<?php require('partials/footer.php') ?>
