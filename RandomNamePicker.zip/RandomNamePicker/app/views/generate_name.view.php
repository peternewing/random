<?php
    $title = "Generate Random Name";
    require('partials/header.php')
?>

<main class="container">

  <h1 class="text-center m-5"><?=  $title ?></h1>

<div class="row">
    <div class="col-md-6 p-2">
        <h2 class="my-4 text-center"></h2>
        <form action="generate_name_post" method="post">
        <div class="mb-3">
            <label for="gender" class="form-label">Select Gender</label>
            <select class="form-select" id="gender" name="gender">
                <option value="any" <?= isset($gender) && $gender == "any" ? 'selected' : '' ?> >Any</option>
                <option value="male" <?= isset($gender) && $gender == "male" ? 'selected' : '' ?>>Male</option>
                <option value="female" <?= isset($gender) && $gender == "female" ? 'selected' : '' ?>>Female</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="numLastNames" class="form-label">Number of Last Names</label>
            <select class="form-select" id="numLastNames" name="numLastNames">
                <option value="1" <?= isset($numLastNames) && $numLastNames == "1" ? 'selected' : '' ?>>One</option>
                <option value="2" <?= isset($numLastNames) && $numLastNames == "2" ? 'selected' : '' ?>>Two</option>
            </select>
        </div>
            <input type="submit" class="btn btn-primary" value="Generate a Random Name">
        </form>
    </div>
    <div class="col-md-6 p-2">

        <h2 class="my-4 text-center">Random Name Generator Result</h2>

        <?php if (isset($generated_name)) : ?>
            <div class='alert alert-success'>The randomly generated name is: <strong><?=  htmlspecialchars($generated_name) ?></strong></div>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-md-12 p-2">
        <h2 class="my-4 text-center">Your Last 20 Random Names</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Generated Name</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Number of Last Names</th>
                    <th scope="col">Date</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($name_history as $name) : ?>
                    <tr>
                        <td><?=  htmlspecialchars($name->generated_name) ?></td>
                        <td><?=  htmlspecialchars($name->gender) ?></td>
                        <td><?=  htmlspecialchars($name->num_last_names) ?></td>
                        <td><?=  htmlspecialchars($name->date) ?></td>
                        <td>
                            <a href="generate_name?name_id=<?=  htmlspecialchars($name->id) ?>" class="btn btn-primary">Details</a>
                        </td>
                    </tr>

                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>



</main>


<?php require('partials/footer.php') ?>