<?php
    $title = "Random Name Picker";
    require('partials/header.php')
?>

<main class="container">

  <h1 class="text-center m-5"><?=  $title ?></h1>

<div class="row">
    <div class="col-md-6 p-2">
        <h2 class="my-4 text-center">List Names</h2>
        <form  id="generateFormName" action="random_name_post" method="post">
            <div id="names">
            <?php if (isset($names)) : ?>
                <?php foreach ($names as $name) : ?>
                <div class="mb-3 input-group">
                    <input type="text" name="names[]" class="form-control" value="<?= $name ?>" placeholder="Enter Name">
                    <button type="button" class="btn btn-danger" onclick="this.parentElement.remove()">Remove</button>
                </div>
                <?php endforeach; ?>
                <?php else : ?>
                    <div class="mb-3 input-group">
                    <input type="text" name="names[]" class="form-control" placeholder="Enter Name">
                    <button type="button" class="btn btn-danger" onclick="this.parentElement.remove()">Remove</button>
                </div>
                <?php endif; ?>
            </div>
            <button type="button" class="btn btn-secondary mb-3" onclick="addNameField()">Add Name</button><br>
            <input type="submit" class="btn btn-primary" value="Pick a Random Name ">
        </form>

        <form id="saveFormName" action="save_name_post" method="post">
            <div class="mb-3">
                <label for="ListName" class="form-label">Enter List Name:</label>
                <input type="hidden" name="listId" value="<?= isset($listId)?$listId:null ?>">
                <input type="text" id="ListName" name="ListName" class="form-control" min="1" value="<?= isset($listName)?$listName:null ?>" required>
            </div>
            <input type="submit" class="btn btn-primary" value="Save List">
        </form>


    </div>
    <div class="col-md-6 p-2">

        <h2 class="my-4 text-center">Selected Name</h2>

        <?php if (isset($selected_name)) : ?>
            <h1 class='my-4'>Random Name Picker Result</h1>
            <div class='alert alert-success'>The randomly picked name is: <strong><?= $selected_name ?></strong></div>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-md-12 p-2">
        <h2 class="my-4 text-center">Saved Lists</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                <th scope="col">Name list</th>
                    <th scope="col">Names</th>
                    <th scope="col">Date</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($saved_lists as $lists) : 
                    ?>
                    <tr>
                    <td><?=  htmlspecialchars($lists->list_name) ?></td>
                        <td>
                            <?php 
                                $names = json_decode($lists->names);
                                foreach ($names as $name) : ?>
                                    <span class="badge bg-secondary"><?=  htmlspecialchars($name) ?></span>
                                <?php endforeach; ?>
                        </td>
                        <td><?=  htmlspecialchars($lists->date) ?></td>
                        <td>
                            <a href="random_name?list_id=<?=  htmlspecialchars($lists->id) ?>" class="btn btn-primary">Load List</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</main>


<?php require('partials/footer.php') ?>