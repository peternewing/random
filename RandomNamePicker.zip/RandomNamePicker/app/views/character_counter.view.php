<?php
  $title =  "Character Counter";
    require('partials/header.php')
?>



<main class="container">

  <h1 class="text-center m-5"><?=  $title ?></h1>

<div class="row">
    <div class="col-md-6 p-2">
        <h2 class="my-4 text-center"></h2>

        <form action="character_counter_post" method="post">
        <div class="form-group">
            <label for="text">Enter Text:</label>
            <textarea class="form-control" id="text" name="text" rows="5"><?= isset($text) ? $text : '' ?></textarea>
        </div>
            <input type="submit" class="btn btn-primary" value="Count Characters">
        </form>

    </div>
    <div class="col-md-6 p-2">

    <h2 class="my-4 text-center">Result</h2>

<?php if (isset($charCount)) : ?>
    <div class='alert alert-success'>The number of characters in the text is: <strong><?=  htmlspecialchars($charCount) ?></strong></div>
<?php endif; ?>

<?php if (isset($wordCount)) : ?>
    <div class='alert alert-success'>The number of words in the text is: <strong><?=  htmlspecialchars($wordCount) ?></strong></div>

<?php endif; ?>

<?php if (isset($lineCount)) : ?>
    <div class='alert alert-success'>The number of lines in the text is: <strong><?=  htmlspecialchars($lineCount) ?></strong></div>

<?php endif; ?>


    </div>
</div>

</main>



<?php require('partials/footer.php') ?>