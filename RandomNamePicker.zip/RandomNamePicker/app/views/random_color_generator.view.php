<?php
    $title = "Random Color Generator"  ;
    require('partials/header.php')
?>

<main class="container">

  <h1 class="text-center m-5"><?=  $title ?></h1>

<div class="row">
    <div class="col-md-6 p-2">
        <h2 class="my-4 text-center"></h2>

        <form action="random_color_generator_post" method="post">
            <input type="submit" class="btn btn-primary" value="Generate a Random Color">
        </form>
    </div>
    <div class="col-md-6 p-2">

        <h2 class="my-4 text-center">Random Color Generator Result <span style="margin-left:20px; min-width: 25px; padding:10px 25px; height : 15px ; background-color :<?=  htmlspecialchars($color) ?>"></span></h2>

        <?php if (isset($color)) : ?>
            <div class='alert alert-success'>The randomly generated color is: <strong><?=  htmlspecialchars($color) ?></strong></div>
        <?php endif; ?>

    


    </div>
</div>
    
        <div class="row">
          <div class="col-md-6 p-2">
                <h2 class="my-4 text-center">Color History</h2>
                <table class="table table-striped">
                 <thead>
                      <tr>
                            <th scope="col">Color</th>
                            <th scope="col">Date</th>
                      </tr>
                 </thead>
                 <tbody>
                      <?php foreach ($color_history as $color) : ?>
                            <tr>
                             <td><?=  htmlspecialchars($color->color) ?>  <span style="margin-left:20px; min-width: 25px; padding:10px 25px; height : 15px ; background-color :<?=  htmlspecialchars($color->color)  ?>"></span></td>
                             <td><?=  htmlspecialchars($color->date) ?></td>
                            </tr>
                      <?php endforeach; ?>
                 </tbody>
                </table>
          </div>
     </div>
     

</main>


<?php require('partials/footer.php') ?>