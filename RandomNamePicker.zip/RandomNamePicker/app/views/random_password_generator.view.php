<?php
    $title = "Random Password Generator"  ;
    require('partials/header.php')
?>

<main class="container">

  <h1 class="text-center m-5"><?=  $title ?></h1>

<div class="row">
    <div class="col-md-6 p-2">
        <h2 class="my-4 text-center"></h2>

        <form action="random_password_generator_post" method="post">
            <div class="mb-3">
                <label for="numChars" class="form-label">Number of Characters</label>
                <input type="number" class="form-control" id="numChars" name="numChars" value="<?= isset($numChars) ? $numChars : '' ?>">
            </div>
            <div class="mb-3">
                <label for="includeUppercase" class="form-label">Include Uppercase Letters</label>
                <input type="checkbox" class="form-check-input" id="includeUppercase" name="includeUppercase" <?= isset($includeUppercase) && $includeUppercase == "on" ? 'checked' : '' ?>>
            </div>
            <div class="mb-3">
                <label for="includeNumbers" class="form-label">Include Numbers</label>
                <input type="checkbox" class="form-check-input" id="includeNumbers" name="includeNumbers" <?= isset($includeNumbers) && $includeNumbers == "on" ? 'checked' : '' ?>>
            </div>
            <div class="mb-3">
                <label for="includeSymbols" class="form-label">Include Symbols</label>
                <input type="checkbox" class="form-check-input" id="includeSymbols" name="includeSymbols" <?= isset($includeSymbols) && $includeSymbols == "on" ? 'checked' : '' ?>>
            </div>
            <input type="submit" class="btn btn-primary" value="Generate a Random Password">
        </form>
        
    
        
    </div>
    <div class="col-md-6 p-2">

        <h2 class="my-4 text-center">Random Passord Generator Result</h2>

        <?php if (isset($random_password)) : ?>
            <div class='alert alert-success'>The randomly generated password is: <strong><?=  htmlspecialchars($random_password) ?></strong></div>
        <?php endif; ?>
    </div>
</div>


        <div class="row">
          <div class="col-md-12 p-2">
                <h2 class="my-4 text-center">Password History</h2>
                <table class="table table-striped">
                 <thead>
                       <tr>
                             <th scope="col">Password</th>
                             <th scope="col">Date</th>
                             <th scope="col">Length</th>
                             <th scope="col">Special Characters</th>
                             <th scope="col">Numbers</th>
                             <th scope="col">Uppercase</th>
                             <th scope="col">Action</th>
                       </tr>
                 </thead>
                 <tbody>
                       <?php foreach ($password_history as $password) : ?>
                             <tr>
                              <td><?=  htmlspecialchars($password->password) ?></td>
                              <td><?=  htmlspecialchars($password->date) ?></td>
                              <td><?=  htmlspecialchars($password->length) ?></td>
                              <td><?=  htmlspecialchars($password->special_chars) ? 'yes' : 'no'?></td>
                              <td><?=  htmlspecialchars($password->numbers) ? 'yes' : 'no' ?></td>
                              <td><?=  htmlspecialchars($password->uppercase) ? 'yes' : 'no' ?></td>
                              <td> 
                                <a href="random_password_generator?password_id=<?= $password->id ?>" class="btn btn-primary">Load Configuration </a>
                             </tr>
                       <?php endforeach; ?>
                 </tbody>
                </table>
          </div>
     </div>


</main>


<?php require('partials/footer.php') ?>