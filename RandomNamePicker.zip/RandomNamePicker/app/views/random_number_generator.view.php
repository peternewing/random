<?php
    $title = "Random Number Generator"  ;
    require('partials/header.php')
?>

<main class="container">

  <h1 class="text-center m-5"><?=  $title ?></h1>

<div class="row">
    <div class="col-md-6 p-2">
        <h2 class="my-4 text-center"></h2>

        <form action="random_number_generator_post" method="post">
            <div class="mb-3">
                <label for="min" class="form-label">Minimum Number</label>
                <input type="number" class="form-control" id="min" name="min" value="<?= isset($min) ? $min : '' ?>">
            </div>
            <div class="mb-3">
                <label for="max" class="form-label">Maximum Number</label>
                <input type="number" class="form-control" id="max" name="max" value="<?= isset($max) ? $max : '' ?>">
            </div>
            <input type="submit" class="btn btn-primary" value="Generate a Random Number">
        </form>
        
        
    </div>
    <div class="col-md-6 p-2">

        <h2 class="my-4 text-center">Random Number Generator Result</h2>

        <?php if (isset($random_number)) : ?>
            <div class='alert alert-success'>The randomly generated number is: <strong><?=  htmlspecialchars($random_number) ?></strong></div>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-md-12 p-2">
        <h2 class="my-4 text-center">Your Last 20 Random Numbers</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Random Number</th>
                    <th scope="col">Minimum Number</th>
                    <th scope="col">Maximum Number</th>
                    <th scope="col">Date</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($number_history as $number) : ?>
                    <tr>
                        <td><?=  htmlspecialchars($number->random_number) ?></td>
                        <td><?=  htmlspecialchars($number->min) ?></td>
                        <td><?=  htmlspecialchars($number->max) ?></td>
                        <td><?=  htmlspecialchars($number->date) ?></td>
                        <td>
                            <a href="random_number_generator?number_id=<?=  htmlspecialchars($number->id) ?>" class="btn btn-primary">Details</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</main>


<?php require('partials/footer.php') ?>