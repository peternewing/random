<ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
    <!-- <li><a href="./random_name" class="nav-link text-light px-2">Random Name Picker</a></li>
    <li><a href="./random_team" class="nav-link text-light px-2">Random Team Generator</a></li>
    <li><a href="./generate_name" class="nav-link text-light px-2">Generate Random Name</a></li> -->
    <?php if($currentUser): ?>
        <li><a href="./profile" class="nav-link text-light px-2">Profile</a></li>
        <li> 
            <form class="logout-form" action="logout" method="post">
                <div class="form-group">
                    <button class="nav-link text-light px-2" type="submit">Logout</button>
                </div>
            </form>
        </li>
    <?php else: ?>
        <li>
            <div class="dropdown">
                <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">
                Login
                </button>
                <form class="dropdown-menu p-4 login-dropdown-form" method="POST" action="login">
                <div class="mb-3">
                    <label for="exampleDropdownFormEmail2" class="form-label">Email address</label>
                    <input type="email" class="form-control" name="email" id="exampleDropdownFormEmail2" placeholder="email@example.com">
                </div>
                <div class="mb-3">
                    <label for="exampleDropdownFormPassword2" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" id="exampleDropdownFormPassword2" placeholder="Password">
                </div>
                <div class="mb-3">
                    <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="dropdownCheck2">
                    <label class="form-check-label" for="dropdownCheck2">
                        Remember me
                    </label>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Sign in</button>
                </form>
            </div>
        </li>
        <li><a href="./register_form" class="nav-link text-light px-2">Register</a></li>
    <?php endif; ?>
</ul>