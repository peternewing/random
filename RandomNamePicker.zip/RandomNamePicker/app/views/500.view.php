<?php
    require('partials/header.php')
?>

<main class="container">
    <h1 class="text-center m-5">500 </h1>
    <h2 class="text-center m-5"><?=$title?> </h2>
</main>

<?php require('partials/footer.php') ?>
