<?php
    $title =  "Online Dice Roller";
    require('partials/header.php')
?>

<main class="container">

  <h1 class="text-center m-5"><?=  $title ?></h1>

  <div class="row">
    <div class="col-md-6 p-2">
        <h2 class="my-4 text-center"></h2>
        <form action="dice_roller_post" method="post">
    <div class="mb-3">
        <label for="numDice" class="form-label">Number of Dice</label>
        <select class="form-select" id="numDice" name="numDice">
            <option value="1" <?= isset($numDice) && $numDice == "1" ? 'selected' : '' ?>>One</option>
            <option value="2" <?= isset($numDice) && $numDice == "2" ? 'selected' : '' ?>>Two</option>
            <option value="3" <?= isset($numDice) && $numDice == "3" ? 'selected' : '' ?>>Three</option>
            <option value="4" <?= isset($numDice) && $numDice == "4" ? 'selected' : '' ?>>Four</option>
            <option value="5" <?= isset($numDice) && $numDice == "5" ? 'selected' : '' ?>>Five</option>
            <option value="6" <?= isset($numDice) && $numDice == "6" ? 'selected' : '' ?>>Six</option>
        </select>
    </div>
    <input type="submit" class="btn btn-primary" value="Roll the Dice">

  
</form>
    </div>
    <div class="col-md-6 p-2">

        <h2 class="my-4 text-center">Result</h2>

        <?php if (isset($dice_rolls)) : ?>
            <div class='alert alert-success'>The dice rolls are: <strong><?=  htmlspecialchars($dice_rolls) ?></strong><br>
            Total: <strong><?=  htmlspecialchars($total) ?></strong>
        </div>
        <?php endif; ?>
    </div>
</div>

        <div class="row">
            <div class="col-md-6 p-2">
                <h2 class="my-4 text-center">Dice Roll History</h2>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Dice Rolls</th>
                            <th scope="col">Total</th>
                            <th scope="col">Number of Rolls</th>
                            <th scope="col">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dice_history as $dice) : ?>
                            <tr>
                                <td><?=  htmlspecialchars($dice->dice_rolls) ?></td>
                                <td><?=  htmlspecialchars($dice->total) ?></td>
                                <td><?=  htmlspecialchars($dice->number_of_rolls) ?></td>
                                <td><?=  htmlspecialchars($dice->date) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>




</main>


<?php require('partials/footer.php') ?>