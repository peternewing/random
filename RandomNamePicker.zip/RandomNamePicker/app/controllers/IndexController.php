<?php

require_once "app/models/CoinHistory.php";
require_once "app/models/DiceHistory.php";
require_once "app/models/PasswordHistory.php";
require_once "app/models/ColorHistory.php";
require_once "app/models/NumberHistory.php";
require_once "app/models/NameHistory.php";
require_once "app/models/RandomTeam.php";
require_once "app/models/RandomName.php";

class IndexController
{
    
    public function index()
    {
       
        return Helper::view("index", []);
    }

    public function RandomTeam()
    {
        $current_user = $_SESSION['user'] ?? null;
        if (!$current_user) {
            return Helper::view("random_teams", []);
        }

        if (isset($_GET['teams_id']))
        {
            $teams_id = $_GET['teams_id'];
            $teams = RandomTeam::find($teams_id);
            if ($teams) {
                return Helper::view("random_teams", [ 'participants' => json_decode($teams->participants)  , 'numTeams' => $teams->num_teams  , 'saved_teams'=> $current_user ? RandomTeam::allByUser($current_user['id']):[] ]);
            }
        }
        return Helper::view("random_teams", ['saved_teams'=> $current_user ? RandomTeam::allByUser($current_user['id']):[] ]);
    }

    public function RandomTeamPost()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $participants = $_POST['participants'];
            $numTeams = intval($_POST['numTeams']);
            $current_user = $_SESSION['user'] ?? null;
          
            if (empty($participants) || $numTeams < 1) {
                return Helper::view("random_teams", ['error' => "Please enter valid participants and number of teams."]);
            } else {
                $participants = array_filter(array_map('trim', $participants));
                $teams = $this->generateRandomTeams($participants, $numTeams);
                
                return Helper::view("random_teams", ['teams' => $teams , 'participants' => $participants , 'numTeams' => $numTeams , 'saved_teams'=> $current_user ? RandomTeam::allByUser($current_user['id']):[]]);
            }
        }
    }

    public function SaveRandomTeamPost()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $participants = $_POST['participants'];
            $numTeams = intval($_POST['numTeams']);
            $teamName = $_POST['TeamName'];
            $teamId = $_POST['teamId'];
      
            if (empty($participants) || $numTeams < 1) {
                return Helper::view("random_teams", ['error' => "Please enter valid participants and number of teams."]);
            } else {
                $current_user = $_SESSION['user'] ?? null;
                if ($current_user) {
                    $randomTeam = new RandomTeam();
                    $randomTeam->team_name = $teamName;
                    $randomTeam->num_teams =$numTeams;
                    $randomTeam->participants =json_encode(array_filter(array_map('trim', $participants)));
                    $randomTeam->user_id = $current_user['id'];
                    $randomTeam->create();
                }

                $participants = array_filter(array_map('trim', $participants));
                $teams = $this->generateRandomTeams($participants, $numTeams);
                return Helper::view("random_teams", ['teams' => $teams , 'participants' => $participants , 'numTeams' => $numTeams, 'saved_teams'=> $current_user ? RandomTeam::allByUser($current_user['id']):[] ]);
            }
        }
    }
    

    function generateRandomTeams($participants, $numTeams) {
        shuffle($participants);
        $teams = array_fill(0, $numTeams, []);
        $teamIndex = 0;
        foreach ($participants as $participant) {
            $teams[$teamIndex][] = $participant;
            $teamIndex = ($teamIndex + 1) % $numTeams;
        }
        return $teams;
    }

    public function RandomName()
    {
        $current_user = $_SESSION['user'] ?? null;
        if (!$current_user) {
            return Helper::view("random_name", []);
        }

        if (isset($_GET['list_id']))
        {
            $list_id = $_GET['list_id'];
            $list = RandomName::find($list_id);
            if ($list) {
                return Helper::view("random_name", [ 'names' => json_decode($list->names)  , 'saved_lists'=> $current_user ? RandomName::allByUser($current_user['id']):[] ]);
            }
        }
        return Helper::view("random_name", ['saved_lists'=> $current_user ? RandomName::allByUser($current_user['id']):[] ]);
    }


    public function RandomNamePost()
    {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $names = $_POST['names'];
            $current_user = $_SESSION['user'] ?? null;
          
            $current_user = $_SESSION['user'] ?? null;
            if (empty($names)) {
                return Helper::view("random_name", ['error' => "Please enter at least one participant." , 'saved_lists'=> $current_user ? RandomName::allByUser($current_user['id']):[] ]);
            }
             else {
                $randomIndex = array_rand($names);
                $selected_name = $names[$randomIndex];
                
                return Helper::view("random_name", ['selected_name' => $selected_name , 'names' => $names, 'saved_lists'=> $current_user ? RandomName::allByUser($current_user['id']):[] ]);
            }
        }
    }
    


    public function SaveRandomNamePost()
    {

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $names = $_POST['names'];
            $listName = $_POST['ListName'];
            $listId = $_POST['listId'];
            $current_user = $_SESSION['user'] ?? null;
            if (empty($names)) {
                return Helper::view("random_name", ['error' => "Please enter at least one participant." , 'saved_lists'=> $current_user ? RandomName::allByUser($current_user['id']):[] ]);
            } else {
               
                if ($current_user) {
                    $list = new RandomName();
                    $list->list_name = $listName;
                    $list->names =json_encode(array_filter(array_map('trim', $names)));
                    $list->user_id = $current_user['id'];
                    $list->create();
                }

                $randomIndex = array_rand($names);
                $selected_name = $names[$randomIndex];

                return Helper::view("random_name", ['selected_name' => $selected_name , 'names' => $names, 'saved_lists'=> $current_user ? RandomName::allByUser($current_user['id']):[] ]);
            }
        }

    }


    public function GenerateName()
    {

        $current_user = $_SESSION['user'] ?? null;
        if (!$current_user) {
            return Helper::view("generate_name", []);
        }

        if (isset($_GET['name_id']))
        {
            $name_id = $_GET['name_id'];
            $name = NameHistory::find($name_id);
            if ($name) {
                return Helper::view("generate_name", ['generated_name' => $name->generated_name , 'gender' => $name->gender , 'numLastNames'  => $name->num_last_names  , 'name_history'=> $current_user ? NameHistory::allByUser($current_user['id']):[]]);
            }
        }
        return Helper::view("generate_name", ['name_history'=> $current_user ? NameHistory::allByUser($current_user['id']):[]]);
    }


    
    public function GenerateNamePost()
    {
        if (isset($_POST['gender']) && isset($_POST['numLastNames'])) {

            $generated_name = $this->generateRandomName($_POST['gender'] , $_POST['numLastNames']) ;

            $current_user = $_SESSION['user'] ?? null;
            if ($current_user) {
                $nameHistory = new NameHistory();
                $nameHistory->generated_name = $generated_name;
                $nameHistory->gender = $_POST['gender'];
                $nameHistory->num_last_names = $_POST['numLastNames'];
                $nameHistory->user_id = $current_user['id'];
                $nameHistory->create();
            }

            return Helper::view("generate_name", ['generated_name' =>$generated_name , 'gender' => $_POST['gender'] , 'numLastNames' => $_POST['numLastNames'] , 'name_history'=> $current_user ? NameHistory::allByUser($current_user['id']):[]]);

        }
    }


    function generateRandomName($gender = 'any', $numLastNames = 1) {
        $maleFirstNames = [
            "Aaron", "Abdul", "Abel", "Abraham", "Adam", "Adrian", "Aidan", "Alan", "Albert", "Alec",
            "Alex", "Alexander", "Alfred", "Andrew", "Anthony", "Arthur", "Asher", "Austin", "Avery", "Barry",
            "Benjamin", "Blake", "Brandon", "Brian", "Bruce", "Bryan", "Caleb", "Calvin", "Cameron", "Carl",
            "Carlos", "Carter", "Charles", "Chris", "Christian", "Christopher", "Clayton", "Clifford", "Colin", "Connor",
            "Curtis", "Cyrus", "Damian", "Daniel", "David", "Dennis", "Derek", "Derrick", "Devin", "Dominic",
            "Donald", "Douglas", "Drew", "Dylan", "Edward", "Edwin", "Elijah", "Elliott", "Eric", "Ethan",
            "Eugene", "Evan", "Everett", "Felix", "Finn", "Frank", "Gabriel", "Gavin", "George", "Gerald",
            "Gilbert", "Gordon", "Graham", "Grant", "Gregory", "Harold", "Harry", "Henry", "Herbert", "Hugh",
            "Hunter", "Ian", "Isaac", "Isaiah", "Ivan", "Jack", "Jackson", "Jacob", "James", "Jason",
            "Jeffrey", "Jeremy", "Jerry", "Jesse", "Jim", "Joe", "John", "Jonathan", "Jordan", "Joseph",
            "Joshua", "Julian", "Justin", "Keith", "Kevin", "Kirk", "Kyle", "Lance", "Lawrence", "Leo",
            "Leonard", "Liam", "Logan", "Louis", "Lucas", "Luke", "Malcolm", "Marcus", "Mark", "Marshall",
            "Martin", "Mason", "Matthew", "Max", "Maxwell", "Michael", "Mitchell", "Morgan", "Nathan", "Nathaniel",
            "Neil", "Nicholas", "Noah", "Norman", "Oliver", "Oscar", "Owen", "Patrick", "Paul", "Peter",
            "Philip", "Phillip", "Quentin", "Ralph", "Randall", "Raymond", "Reed", "Reginald", "Richard", "Rick",
            "Riley", "Robert", "Rodney", "Roger", "Ronald", "Ross", "Roy", "Russell", "Ryan", "Sam",
            "Samuel", "Scott", "Sean", "Seth", "Shane", "Shawn", "Spencer", "Stanley", "Stephen", "Steven",
            "Stuart", "Taylor", "Terrence", "Theodore", "Thomas", "Timothy", "Todd", "Travis", "Trevor", "Tristan",
            "Troy", "Tyler", "Victor", "Vincent", "Wade", "Walter", "Warren", "Wayne", "Wesley", "William",
            "Wyatt", "Xavier", "Zachary", "Zane", "Aaron", "Abdul", "Abel", "Abraham", "Adam", "Adrian",
            "Aidan", "Alan", "Albert", "Alec", "Alex", "Alexander", "Alfred", "Andrew", "Anthony", "Arthur",
            "Asher", "Austin", "Avery", "Barry", "Benjamin", "Blake", "Brandon", "Brian", "Bruce", "Bryan",
            "Caleb", "Calvin", "Cameron", "Carl", "Carlos", "Carter", "Charles", "Chris", "Christian", "Christopher",
            "Clayton", "Clifford", "Colin", "Connor", "Curtis", "Cyrus", "Damian", "Daniel", "David", "Dennis",
            "Derek", "Derrick", "Devin", "Dominic", "Donald", "Douglas", "Drew", "Dylan", "Edward", "Edwin",
            "Elijah", "Elliott", "Eric", "Ethan", "Eugene", "Evan", "Everett", "Felix", "Finn", "Frank",
            "Gabriel", "Gavin", "George", "Gerald", "Gilbert", "Gordon", "Graham", "Grant", "Gregory", "Harold",
            "Harry", "Henry", "Herbert", "Hugh", "Hunter", "Ian", "Isaac", "Isaiah", "Ivan", "Jack",
            "Jackson", "Jacob", "James", "Jason", "Jeffrey", "Jeremy", "Jerry", "Jesse", "Jim", "Joe"
        ];
        $femaleFirstNames = [
            "Abigail", "Ada", "Adelaide", "Adele", "Adeline", "Adriana", "Aileen", "Aimee", "Alana", "Alanna",
            "Alexandra", "Alice", "Alicia", "Alison", "Allison", "Alyssa", "Amanda", "Amber", "Amelia", "Amy",
            "Ana", "Andrea", "Angela", "Angelina", "Anna", "Anne", "Annie", "Ariana", "Ariel", "Ashley",
            "Audrey", "Aurora", "Ava", "Barbara", "Beatrice", "Bella", "Bernice", "Beth", "Bianca", "Bonnie",
            "Brenda", "Brianna", "Brooke", "Camila", "Candice", "Cara", "Carla", "Carmen", "Caroline", "Carolyn",
            "Catherine", "Cecilia", "Celeste", "Charlotte", "Cheryl", "Chloe", "Christina", "Claire", "Clara", "Claudia",
            "Colleen", "Connie", "Cynthia", "Daisy", "Dana", "Danielle", "Daphne", "Darlene", "Deborah", "Delia",
            "Denise", "Diana", "Diane", "Donna", "Dorothy", "Edith", "Eileen", "Elaine", "Elena", "Elisa",
            "Eliza", "Elizabeth", "Ella", "Ellen", "Ellie", "Emily", "Emma", "Erica", "Erin", "Esther",
            "Eva", "Evelyn", "Faith", "Fiona", "Frances", "Gabriella", "Georgia", "Gillian", "Grace", "Hannah"
        ];
        $lastNames = [
            "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
            "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin",
            "Lee", "Perez", "Thompson", "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson",
            "Walker", "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores", "Green",
            "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell", "Mitchell", "Carter", "Roberts", "Gomez",
            "Phillips", "Evans", "Turner", "Diaz", "Parker", "Cruz", "Edwards", "Collins", "Reyes", "Stewart",
            "Morris", "Morales", "Murphy", "Cook", "Rogers", "Gutierrez", "Ortiz", "Morgan", "Cooper", "Peterson",
            "Bailey", "Reed", "Kelly", "Howard", "Ramos", "Kim", "Cox", "Ward", "Richardson", "Watson",
            "Brooks", "Chavez", "Wood", "James", "Bennett", "Gray", "Mendoza", "Ruiz", "Hughes", "Price",
            "Alvarez", "Castillo", "Sanders", "Patel", "Myers", "Long", "Ross", "Foster", "Jimenez", "Powell",
            "Jenkins", "Perry", "Russell", "Sullivan", "Bell", "Cole", "Butler", "Henderson", "Barnes", "Gonzales"];
        
        if ($gender == 'male') {
            $randomFirstName = $maleFirstNames[array_rand($maleFirstNames)];
        } elseif ($gender == 'female') {
            $randomFirstName = $femaleFirstNames[array_rand($femaleFirstNames)];
        } else {
            $allFirstNames = array_merge($maleFirstNames, $femaleFirstNames);
            $randomFirstName = $allFirstNames[array_rand($allFirstNames)];
        }

        $randomLastName1 = $lastNames[array_rand($lastNames)];
        $randomLastName2 = $lastNames[array_rand($lastNames)];

        if ($numLastNames == 2) {
            $randomLastName = $randomLastName1 . " " . $randomLastName2;
        } else {
            $randomLastName = $randomLastName1;
        }

        return $randomFirstName . " " . $randomLastName;
    }


    function DiceRoller() {
        $current_user = $_SESSION['user'] ?? null;
        return Helper::view("dice_roller", ['dice_history'=> $current_user ? DiceHistory::allByUser($current_user['id']):[] ]);
    }

    function RollDicePost() {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $numDice = $_POST['numDice'];
            $dice_rolls = $this->rollDice($numDice);
            $current_user = $_SESSION['user'] ?? null;
            if ($current_user) {
                $diceHistory = new DiceHistory();
                $diceHistory->dice_rolls = $dice_rolls['dices'];
                $diceHistory->total = $dice_rolls['total'];
                $diceHistory->number_of_rolls = $numDice;
                $diceHistory->user_id = $current_user['id'];
                $diceHistory->create();
            }
            return Helper::view("dice_roller", ['dice_rolls' => $dice_rolls['dices']  , 'total' => $dice_rolls['total']  , 'numDice' => $numDice , 'dice_history'=>  $current_user ?DiceHistory::allByUser($current_user['id']):[]]);
        }
    }

    function rollDice($numDice) {
        $dice_rolls = [];
        for ($i = 0; $i < $numDice; $i++) {
            $dice_rolls[] = rand(1, 6);
        }
        return [ 'dices'=> implode(", ", $dice_rolls) , 'total' => array_sum($dice_rolls)];
    }

    function FlipACoin() {
        $current_user = $_SESSION['user'] ?? null;
        return Helper::view("flip_coin", ['coin_history'=> $current_user ? CoinHistory::allByUser($current_user['id']):[] ]);
    }

    function FlipACoinPost() {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $coin = $this->flipCoin();
            $current_user = $_SESSION['user'] ?? null;
            if ($current_user) {
                $coinHistory = new CoinHistory();
                $coinHistory->coin_side = $coin;
                $coinHistory->user_id = $current_user['id'];
                $coinHistory->create();
            }

            return Helper::view("flip_coin", ['coin_flip' => $coin , 'coin_history'=>$current_user ? CoinHistory::allByUser($current_user['id'] ) :[] ]);
        }
    }

    function flipCoin() {
        return rand(0, 1) == 0 ? "Heads" : "Tails";
    }


    function RandomNumberGenerator() {
        $current_user = $_SESSION['user'] ?? null;
        if (!$current_user) {
            return Helper::view("random_number_generator", []);
        }

        if (isset($_GET['number_id']))
        {
            $number_id = $_GET['number_id'];
            $number = NumberHistory::find($number_id);
            if ($number) {
                return Helper::view("random_number_generator", ['random_number' => $number->random_number , 'min' => $number->min , 'max' => $number->max , 'number_history'=> $current_user ? NumberHistory::allByUser($current_user['id']):[]]);
            }
        }

        return Helper::view("random_number_generator", ['number_history'=> $current_user ? NumberHistory::allByUser($current_user['id']):[]]);
    }

    function RandomNumberGeneratorPost() {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $min =isset($_POST['min']) && $_POST['min'] != '' ?  $_POST['min'] : 0  ;
            $max =isset($_POST['max']) && $_POST['max'] != '' ?  $_POST['max'] : 100  ;
            $random_number = $this->generateRandomNumber($min, $max);
            $current_user = $_SESSION['user'] ?? null;
            if ($current_user) {
                $numberHistory = new NumberHistory();
                $numberHistory->random_number = $random_number;
                $numberHistory->min = $min;
                $numberHistory->max = $max;
                $numberHistory->user_id = $current_user['id'];
                $numberHistory->create();
            }

            return Helper::view("random_number_generator", ['random_number' => $random_number , 'min' => $min , 'max' => $max , 'number_history'=> $current_user ? NumberHistory::allByUser($current_user['id']):[]]);

        }
    }

    function generateRandomNumber($min, $max) {
        return rand($min, $max);
    }

    function RandomPasswordGenerator() {

      
        $current_user = $_SESSION['user'] ?? null;
        if (!$current_user) {
            return Helper::view("random_password_generator", []);
        }
        if (isset($_GET['password_id']))
        {
            $password_id = $_GET['password_id'];
            $password = PasswordHistory::find($password_id);
            if ($password) {
                return Helper::view("random_password_generator", ['random_password' => $password->password , 'numChars' => $password->length , 'includeUppercase' => $password->uppercase ? 'on' : '', 'includeNumbers' => $password->numbers ? 'on' : '', 'includeSymbols' => $password->special_chars ? 'on' : '', 'password_history'=> $current_user ? PasswordHistory::allByUser($current_user['id']):[] ]);
            }
        }
        return Helper::view("random_password_generator", ['password_history'=> $current_user ? PasswordHistory::allByUser($current_user['id']):[] ]);
    }

    function RandomPasswordGeneratorPost() {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
          
            $numChars = $_POST['numChars'];
            $includeUppercase = isset($_POST['includeUppercase']) ? $_POST['includeUppercase'] : false;
            $includeNumbers = isset($_POST['includeNumbers']) ? $_POST['includeNumbers'] : false;
            $includeSymbols = isset($_POST['includeSymbols']) ? $_POST['includeSymbols'] : false;

            if ($numChars < 1) {
                return Helper::view("random_password_generator", ['error' => "Please enter a valid number of characters."]);
            } else {
                $random_password = $this->generateRandomPassword($numChars, $includeUppercase, $includeNumbers, $includeSymbols);

                $current_user = $_SESSION['user'] ?? null;
                if ($current_user) {
                    $passwordHistory = new PasswordHistory();
                    $passwordHistory->password = $random_password;
                    $passwordHistory->length = $numChars;
                    $passwordHistory->special_chars = $includeSymbols;
                    $passwordHistory->numbers = $includeNumbers;
                    $passwordHistory->uppercase = $includeUppercase;
                    $passwordHistory->user_id = $current_user['id'];
                    $passwordHistory->create();
                }

                return Helper::view("random_password_generator", ['random_password' => $random_password , 'numChars' => $numChars , 'includeUppercase' => $includeUppercase , 'includeNumbers' => $includeNumbers , 'includeSymbols' => $includeSymbols , 'password_history'=> $current_user ? PasswordHistory::allByUser($current_user['id']):[]]);
            }

        }
    }

    function generateRandomPassword($numChars, $includeUppercase, $includeNumbers, $includeSymbols) {
        $chars = 'abcdefghijklmnopqrstuvwxyz';
        $chars .= $includeUppercase ? 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' : '';
        $chars .= $includeNumbers ? '0123456789' : '';
        $chars .= $includeSymbols ? '!@#$%^&*()_+-=[]{}|;:,.<>?~' : '';
        $chars = str_shuffle($chars);
        return substr($chars, 0, $numChars);
    }


    function RandomColorGenerator() {
        $current_user = $_SESSION['user'] ?? null;
        return Helper::view("random_color_generator", ['color_history'=> $current_user ? ColorHistory::allByUser($current_user['id']):[] ]);
    }

    function RandomColorGeneratorPost() {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $color = $this->generateRandomColor();
            $current_user = $_SESSION['user'] ?? null;
            if ($current_user) {
               $colorHistory = new ColorHistory();
                $colorHistory->color = $color;
                $colorHistory->user_id = $current_user['id'];
                $colorHistory->create();
            }

            return Helper::view("random_color_generator", ['color' => $color , 'color_history'=> $current_user ? ColorHistory::allByUser($current_user['id']):[]]);
        }
    }

    function generateRandomColor() {
        return '#' . str_pad(dechex(mt_rand(0, 0xFFFFFF)), 6, '0', STR_PAD_LEFT);
    }

    function CharacterCounter() {
        return Helper::view("character_counter", []);
    }

    function CharacterCounterPost() {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $text = $_POST['text'];
            $charCount = strlen($text);
            $wordCount = str_word_count($text);
            $lineCount = substr_count($text, "\n") + 1;
            return Helper::view("character_counter", ['charCount' => $charCount , 'wordCount' => $wordCount , 'lineCount' => $lineCount , 'text' => $text]);
        }
    }

}
