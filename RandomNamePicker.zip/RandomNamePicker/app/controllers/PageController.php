<?php

class PageController
{
   
    public function pageRandomNamePicker()
    {
        $title = "Random Name Picker";
        return Helper::view('page_random_name_picker',['title' => $title]);
    }

    public function pageRandomTeamGenerator()
    {
        $title = "Random Team Generator";
        return Helper::view('page_random_team_generator',['title' => $title]);
    }

    public function pageGenerateRandomName()
    {
        $title = "Generate Random Name";
        return Helper::view('page_generate_random_name',['title' => $title]);
    }

    public function pageDiceRoller()
    {
        $title = "Dice Roller";
        return Helper::view('page_dice_roller',['title' => $title]);
    }

    public function pageFlipACoin()
    {
        $title = "Flip a Coin";
        return Helper::view('page_flip_a_coin',['title' => $title]);
    }

    public function pageRandomNumberGenerator()
    {
        $title = "Random Number Generator";
        return Helper::view('page_random_number_generator',['title' => $title]);
    }

    public function pageRandomPasswordGenerator()
    {
        $title = "Random Password Generator";
        return Helper::view('page_random_password_generator',['title' => $title]);
    }

    public function pageRandomColorGenerator()
    {
        $title = "Random Color Generator";
        return Helper::view('page_random_color_generator',['title' => $title]);
    }

    public function pageCharacterCounter()
    {
        $title = "Character Counter";
        return Helper::view('page_character_counter',['title' => $title]);
    }

}


