<?php

require_once "app/models/User.php";

class UserController
{
   
    public function loginForm()
    {
        //logut if already logged in
        unset($_SESSION['user']) ; 
        return Helper::view("login");
    }

    public function login()
    {
       
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['username'];
            $password = $_POST['password'];
            $user_id = User::login($email, $password);
           if($user_id)
           {
                // Redirect to home page after login
                Helper::session('message', 'Login successful');
                Helper::redirect(''); 
           }
           else
           {
                //redirect to login page with error
                Helper::session('error', 'Invalid username or password');
                Helper::redirect('login_form');
           }

        }
    }


    public function registerForm()
    {
        //logut if already logged in
        unset($_SESSION['user']) ; 
        return Helper::view("register");
    }

    public function register()
    {
      
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $first_name = $_POST['firstName'];
            $last_name = $_POST['lastName'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $password_confirmation = $_POST['password_confirmation'];

            if($password != $password_confirmation)
            {
                Helper::session('error', 'Password and password confirmation does not match');
                Helper::redirect('register_form'); 
            }

            $user = new User();
            $user->first_name = $first_name;
            $user->last_name = $last_name;
            $user->email = $email;
            $user->password = password_hash($password, PASSWORD_DEFAULT);
            $user->role = 'user';
            $user->create();
            Helper::session('message', 'User created successfully');
            Helper::redirect('login_form');
            
        }
        else
        {
            Helper::session('error', 'Invalid request');
            Helper::redirect('register_form');
        }

    }

    public function logout()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            //redirect to login page
            Helper::redirect('login_form'); 
        }
    }

    public function profile()
    {
        $user = User::fetchId($_SESSION['user']['id']);
        return Helper::view("profile", ['user' => $user]);
    }

    public function editProfile()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $user = User::fetchId($_SESSION['user']['id']);
            $first_name = $_POST['firstName'];
            $last_name = $_POST['lastName'];
            $password = $_POST['password'];
            $password_confirmation = $_POST['password_confirmation'];

            if($password != $password_confirmation)
            {
                Helper::session('error', 'Password and password confirmation does not match');
                Helper::redirect('profile'); 
            }
            $user->first_name = $first_name;
            $user->last_name = $last_name;
            $user->password = password_hash($password, PASSWORD_DEFAULT);
            $user->role = 'user';
            $user->update();
            Helper::session('message', 'User updated successfully');
            Helper::redirect('profile');
        }
        else
        {
            Helper::session('error', 'Invalid request');
            Helper::redirect('profile');
        }
    }

}
