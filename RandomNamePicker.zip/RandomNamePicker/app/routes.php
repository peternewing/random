<?php

$router->define([

  // public routes
  ''=> ["action" => 'IndexController' , "is_protected" => false], //GET
  'index'=> ["action" => 'IndexController' , "is_protected" => false], //GET
  'random_name'=> ["action" => 'IndexController@RandomName' , "is_protected" => false], //GET
  'random_name_post'=> ["action" => 'IndexController@RandomNamePost' , "is_protected" => false], //Post
  'save_name_post'=> ["action" => 'IndexController@SaveRandomNamePost' , "is_protected" => true], //Post
  'random_team'=> ["action" => 'IndexController@RandomTeam' , "is_protected" => false], //GET
  'generate_teams_post'=> ["action" => 'IndexController@RandomTeamPost' , "is_protected" => false], //Post
  'save_team_post'=> ["action" => 'IndexController@SaveRandomTeamPost' , "is_protected" => true], //Post

  'generate_name'=> ["action" => 'IndexController@GenerateName' , "is_protected" => false], //GET
  'generate_name_post'=> ["action" => 'IndexController@GenerateNamePost' , "is_protected" => false], //Post
  'dice_roller' => ["action" => 'IndexController@DiceRoller' , "is_protected" => false], //GET
  'dice_roller_post' => ["action" => 'IndexController@RollDicePost' , "is_protected" => false], //Post
  'flip_a_coin' => ["action" => 'IndexController@FlipACoin' , "is_protected" => false], //GET
  'flip_a_coin_post' => ["action" => 'IndexController@FlipACoinPost' , "is_protected" => false], //Post
  'random_number_generator' => ["action" => 'IndexController@RandomNumberGenerator' , "is_protected" => false], //GET
  'random_number_generator_post' => ["action" => 'IndexController@RandomNumberGeneratorPost' , "is_protected" => false], //Post
  'random_password_generator' => ["action" => 'IndexController@RandomPasswordGenerator' , "is_protected" => false], //GET
  'random_password_generator_post' => ["action" => 'IndexController@RandomPasswordGeneratorPost' , "is_protected" => false], //Post
  'random_color_generator' => ["action" => 'IndexController@RandomColorGenerator' , "is_protected" => false], //GET
  'random_color_generator_post' => ["action" => 'IndexController@RandomColorGeneratorPost' , "is_protected" => false], //Post
  'character_counter' => ["action" => 'IndexController@CharacterCounter' , "is_protected" => false], //GET
  'character_counter_post' => ["action" => 'IndexController@CharacterCounterPost' , "is_protected" => false], //Post
  


  // auth routes
  'login_form'=> ["action" => 'UserController@loginForm' , "is_protected" => false], //GET
  'login'=> ["action" => 'UserController@login' , "is_protected" => false], //Post
  'register_form'=> ["action" => 'UserController@registerForm' , "is_protected" => false], //GET
  'register'=> ["action" => 'UserController@register' , "is_protected" => false], //Post
  'logout'=>  ["action" => 'UserController@logout' , "is_protected" => true ,'role'=>['user','moderator', 'administrator']], //Post
  'profile'=>  ["action" => 'UserController@profile' , "is_protected" => true,'role'=>['user','moderator', 'administrator']], //Post
  'edit_profile'=>  ["action" => 'UserController@editProfile' , "is_protected" => true,'role'=>['user','moderator', 'administrator']], //Post

  //error routes
  '404' => ["action" => 'ErrorController@notFound' , "is_protected" => false], //GET
  '403' => ["action" => 'ErrorController@forbidden' , "is_protected" => false], //GET
  '500' => ["action" => 'ErrorController@serverError' , "is_protected" => false], //GET


  //error routes
  'article_random_name_picker' => ["action" => 'PageController@pageRandomNamePicker' , "is_protected" => false], //GET
  'article_random_team_generator' => ["action" => 'PageController@pageRandomTeamGenerator' , "is_protected" => false], //GET
  'article_generate_random_name' => ["action" => 'PageController@pageGenerateRandomName' , "is_protected" => false], //GET
  'article_dice_roller' => ["action" => 'PageController@pageDiceRoller' , "is_protected" => false], //GET
  'article_flip_a_coin' => ["action" => 'PageController@pageFlipACoin' , "is_protected" => false], //GET
  'article_random_number_generator' => ["action" => 'PageController@pageRandomNumberGenerator' , "is_protected" => false], //GET
  'article_random_password_generator' => ["action" => 'PageController@pageRandomPasswordGenerator' , "is_protected" => false], //GET
  'article_random_color_generator' => ["action" => 'PageController@pageRandomColorGenerator' , "is_protected" => false], //GET
  'article_character_counter' => ["action" => 'PageController@pageCharacterCounter' , "is_protected" => false], //GET
  





]);
