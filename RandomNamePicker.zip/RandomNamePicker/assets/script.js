function addParticipantField() {
    const participantsDiv = document.getElementById('participants');
    const newDiv = document.createElement('div');
    newDiv.classList.add('mb-3', 'input-group');

    const newInput = document.createElement('input');
    newInput.type = 'text';
    newInput.name = 'participants[]';
    newInput.classList.add('form-control');
    newInput.placeholder = 'Enter Participant Name';

    const removeButton = document.createElement('button');
    removeButton.type = 'button';
    removeButton.classList.add('btn', 'btn-danger');
    removeButton.innerText = 'Remove';
    removeButton.onclick = function() {
        participantsDiv.removeChild(newDiv);
    };

    newDiv.appendChild(newInput);
    newDiv.appendChild(removeButton);
    participantsDiv.appendChild(newDiv);
}


function addNameField() {
    const namesDiv = document.getElementById('names');
    const newDiv = document.createElement('div');
    newDiv.classList.add('mb-3', 'input-group');

    const newInput = document.createElement('input');
    newInput.type = 'text';
    newInput.name = 'names[]';
    newInput.classList.add('form-control');
    newInput.placeholder = 'Enter Name';

    const removeButton = document.createElement('button');
    removeButton.type = 'button';
    removeButton.classList.add('btn', 'btn-danger');
    removeButton.innerText = 'Remove';
    removeButton.onclick = function() {
        namesDiv.removeChild(newDiv);
    };

    newDiv.appendChild(newInput);
    newDiv.appendChild(removeButton);
    namesDiv.appendChild(newDiv);
}

document.getElementById('saveFormName').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting immediately
    const generateFormName = document.getElementById('generateFormName');
    const saveFormName = document.getElementById('saveFormName');
    
    // Append inputs from generateForm to saveForm
    const generateFormData = new FormData(generateFormName);
    for (let [name, value] of generateFormData) {
        let input = document.createElement('input');
        input.type = 'hidden';
        input.name = name;
        input.value = value;
        saveFormName.appendChild(input);
    }

    // Submit the saveFormTeam after appending inputs
    saveFormName.submit();
});


document.getElementById('saveFormTeam').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting immediately
    const generateFormTeam = document.getElementById('generateFormTeam');
    const saveFormTeam = document.getElementById('saveFormTeam');
    
    // Append inputs from generateForm to saveForm
    const generateFormData = new FormData(generateFormTeam);
    for (let [name, value] of generateFormData) {
        let input = document.createElement('input');
        input.type = 'hidden';
        input.name = name;
        input.value = value;
        saveFormTeam.appendChild(input);
    }

    // Submit the saveFormTeam after appending inputs
    saveFormTeam.submit();
});